<?php

return [
    'host' => 'localhost',
    'database' => 'sistema_arquitetura',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4',
    'port' => 3306
];
