<?php

return [
    'host' => 'smtp.gmail.com',
    'port' => 587,
    'encryption' => 'tls',
    'username' => 'seu-email@gmail.com',
    'password' => 'sua-senha-app',
    'from_address' => 'seu-email@gmail.com',
    'from_name' => 'Sistema de Arquitetura'
];
