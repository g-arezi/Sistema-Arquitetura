# 🌐 INSTRUÇÕES PARA HOSPEDAGEM 
 
## 📋 PASSOS PARA COLOCAR ONLINE: 
 
### 1. UPLOAD DOS ARQUIVOS: 
- Extraia este ZIP na pasta public_html/ da sua hospedagem 
- Ou em uma subpasta como public_html/sistema/ 
 
### 2. CONFIGURAR BANCO DE DADOS: 
- Crie um banco MySQL no cPanel 
- Anote: host, banco, usuário, senha 
 
### 3. CONFIGURAR .ENV: 
- Copie .env.example para .env 
- Edite com os dados do seu banco: 
  DB_HOST=localhost 
  DB_NAME=seu_banco 
  DB_USER=seu_usuario 
  DB_PASS=sua_senha 
 
### 4. CONFIGURAR DOMÍNIO: 
- Para subpasta: https://seudominio.com/sistema/public 
- Para subdomínio: Aponte para a pasta /public 
 
### 5. CONFIGURAR PERMISSÕES: 
- Pastas: 755 
- Arquivos: 644 
- storage/: 775 
- logs/: 775 
 
### 6. TESTAR: 
- Acesse a URL configurada 
- Teste login/cadastro 
- Verifique se arquivos são enviados corretamente 
